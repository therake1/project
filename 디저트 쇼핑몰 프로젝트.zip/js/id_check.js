$(function(){

    //아이디 중복 확인 소스
    var IdCheck = $('#id_check');
    var Id = $('#id');
	var RegExp = /[ \{\}\[\]\/?.,;:|\)*~`!^\-_+┼<>@\#$%&\'\"\\\(\=]/gi;
	
    IdCheck.click(function(){
		if( RegExp.test(Id.val())){
			alert('특수문자는 입력할 수 없습니다.');
			exit();
		}
        $.ajax({
            type: 'post',
            dataType: 'json',
            url: '../php/id_check.php',
            data: {Id: Id.val()},
 
            success: function (json) {
                if(json.res=='good') {
                    alert('사용가능한 아이디 입니다.');
                }else{
                    alert('중복되는 아이디입니다.');
                    Id.focus();
                }
            },
 
            error: function(){
              console.log('failed');
            }
        });
    });

});