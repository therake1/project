<?php
 
    $mysqli=mysqli_connect("localhost","root","asdasd","test");
    $Id = $_POST['Id'];
    $sql = "SELECT * FROM customer WHERE c_id = '{$Id}'";
    $res = $mysqli->query($sql);
 
 
    if($res->num_rows >= 1){
        echo json_encode(array('res'=>'bad'));
    }else{
        echo json_encode(array('res'=>'good'));
    }
 
?>