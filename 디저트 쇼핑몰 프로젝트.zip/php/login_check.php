<?php
session_start();
if(!isset($_SESSION['c_id'])){
	$id=$_POST['id'];
	$pw=$_POST['pw'];
}
else{
	$id=$_SESSION['c_id'];
	$pw=$_SESSION['c_passwd'];
}
$mysqli=mysqli_connect("localhost","root","asdasd","test");

$check="SELECT * FROM customer WHERE c_id='$id'";
$result=$mysqli->query($check); 
if($result->num_rows==1){
    $row=$result->fetch_array(MYSQLI_ASSOC); //하나의 열을 배열로 가져오기
    if($row['c_passwd']==$pw){  //MYSQLI_ASSOC 필드명으로 첨자 가능
        $_SESSION['c_id']=$id;		//로그인 성공 시 세션 변수 만들기
		$_SESSION['c_passwd']=$pw;
        if(isset($_SESSION['c_id']))    //세션 변수가 참일 때
        {
			echo "<script>alert('환영합니다.');
			document.location='../html/main.html';</script>";   //로그인 성공 시 페이지 이동
        }
        else{
            echo "세션 저장 실패";
        }
    }
    else{
        echo "<script>alert('비밀번호가 틀렸습니다.');
		document.location='../html/login.html';</script>";
    }
}
else{
    echo "<script>alert('아이디를 입력해 주세요.');
	document.location='../html/login.html';</script>";
}
?>