<?php
session_start();
$p_id=$_GET['p_id'];

$mysqli=mysqli_connect("localhost","root","asdasd","test");

$sql="delete from cart where c_id='{$_SESSION['c_id']}' and p_id={$p_id}";
$result=$mysqli->query($sql);

header('location: ../html/cart.html');

?>