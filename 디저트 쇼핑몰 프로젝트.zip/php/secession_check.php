﻿<?php
session_start();
$id=$_SESSION['c_id'];
$mysqli=mysqli_connect("localhost","root","asdasd","test");
 
$check="DELETE from customer WHERE c_id='$id'";
$result=$mysqli->query($check);


if($result)
{
	session_destroy();
	echo "<script>alert('탈퇴하였습니다.');
	document.location='../html/main.html';</script>";
}
else{
	echo "<script>alert('탈퇴 실패');
	document.location='../html/main.html';</script>";
}

?>