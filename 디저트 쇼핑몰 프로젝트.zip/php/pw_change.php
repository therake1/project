﻿<?php
session_start();
$id=$_SESSION['c_id'];
$pw=$_POST['password'];
$pwc=$_POST['pwc'];
 
if($pw!=$pwc) //비밀번호와 비밀번호 확인 문자열이 맞지 않을 경우
{
    echo "<script>alert('비밀번호와 비밀번호 확인이 서로 다릅니다..');
	document.location='../html/pw_change.html';</script>";
}
if($pw==NULL) //
{
    echo "<script>alert('비밀번호를 채워주세요.');
	document.location='../html/pw_change.html';</script>";
}
 
$mysqli=mysqli_connect("localhost","root","asdasd","test");
 
$check="UPDATE customer SET c_passwd='$pw' where c_id='$id'";
$result=$mysqli->query($check);

if($result){
    echo "<script>alert('비밀번호 변경 완료');
	document.location='../html/main.html';</script>";
}
 
?>