﻿<?php
session_start();
$id=$_POST['id'];
$pw=$_POST['password'];
$pwc=$_POST['pwc'];
$address=$_POST['address'];
$d_address=$_POST['d_address'];
$phone1=$_POST['phone1'];
$phone2=$_POST['phone2'];
$phone3=$_POST['phone3'];

$phone=$phone1.'-'.$phone2.'-'.$phone3;

if($pw!=$pwc) //비밀번호와 비밀번호 확인 문자열이 맞지 않을 경우
{
    echo "<script>alert('비밀번호와 비밀번호 확인이 다릅니다.');
	document.location='../html/register.html';</script>";
}
if($id==NULL || $pw==NULL ) //
{
    echo "<script>alert('아이디 혹은 비밀번호를 입력해 주세요.');
	document.location='../html/register.html';</script>";
}

if($address == NULL)
	$address='NULL';

if($d_address == NULL)
	$d_address='NULL';

if($phone1 == NULL || $phone2 == NULL || $phone3 == NULL)
	$phone='NULL';
 
$mysqli=mysqli_connect("localhost","root","asdasd","test");

$signup=mysqli_query($mysqli,"INSERT INTO customer VALUES ('$id','$pw','$address','$phone','$d_address')");
$_SESSION['c_id']=$id;
$_SESSION['c_passwd']=$pw;
if($signup){
    echo "<script>alert('가입을 축하드립니다.');
	document.location='./login_check.php';</script>";
}
 
?>