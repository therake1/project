<?php
session_start();
if(!isset($_SESSION['c_id'])){
	echo"<script>alert('로그인을 해주세요.');
	document.location='./login.html';</script>";
}

$p_id=$_GET['p_id'];

$mysqli=mysqli_connect("localhost","root","asdasd","test");


$sql="select * from cart where c_id='{$_SESSION['c_id']}' and p_id={$p_id}";
$result=$mysqli->query($sql);

if($result->num_rows >= 1){
	$sql="UPDATE cart SET p_number = p_number +1 where c_id='{$_SESSION['c_id']}' and p_id={$p_id}";
	$result=$mysqli->query($sql);
	$sql="UPDATE cart SET total_price = total_price + p_price where c_id='{$_SESSION['c_id']}' and p_id={$p_id}";
	$result=$mysqli->query($sql);
}
else{
}

echo"<script>alert('장바구니에 추가되었습니다.');
document.location='../html/main.html';</script>";
?>