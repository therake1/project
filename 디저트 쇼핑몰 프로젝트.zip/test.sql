drop database test;

create database test;
use test;

drop table product;
drop table customer;
drop table deliver;
drop table ordering;
drop table confirm;
drop table take_back;
drop table cart;

create table product(
 p_id int(32) primary key,
 p_name varchar(32),
 p_price int(16),
 p_info varchar(255)
);

create table customer(
 c_id varchar(16) primary key,
 c_passwd varchar(16),
 address varchar(255),
 pnumber varchar(16),
 d_address varchar(255)
);

create table deliver(
 c_id varchar(16) primary key,
 address varchar(255),
 pnumber varchar(16)
);

create table ordering(
 c_id varchar(16),
 d_address varchar(255),
 p_id int(32),
 p_price int(16),
 p_number int(8),
 total_price int(32),
 order_date date,
 primary key(c_id, p_id, p_number)
);

create table confirm(
 c_id varchar(16) primary key,
 confirm_birth date,
 CONSTRAINT c_id_cons FOREIGN KEY (c_id) REFERENCES customer(c_id)
);

create table take_back(
 take_back boolean
);

create table cart(
 c_id varchar(16),
 p_id int(32),
 p_name varchar(32),
 p_price int(16),
 p_number int(8),
 total_price int(32),
 primary key(c_id,p_id)
);

insert into product values
(1,'초코파이 기본',7500,'Delicious Chocolate pie'),
(2,'초코파이 녹차맛',9500, 'Delicious Chocolate pie'),
(3,'초코파이 치즈맛',9500, 'Delicious Chocolate pie'),
(4,'풍년제과 초코파이',500000, 'Delicious Chocolate pie'),
(5,'초코파이 녹차맛',9500, 'Delicious Chocolate pie'),
(6,'product1',1500, 'product1'),
(7,'product2',2500, 'product2'),
(8,'product3',3500, 'product3'),
(9,'product4',4500, 'product4'),
(10,'product5',5500, 'product5');

insert into customer values ('moon123', '123123', 'MokPo', '010-1234-1234', 'NamAk');
insert into customer values ('wonjong', '123123', 'YeongAm', '010-2345-6789', 'CheongGye');
insert into customer values ('lee111',  '123123', 'PaJu', '010-7777-8888', 'CheongGye');
insert into customer values ('seok0123','123123', 'North Korea', '010-9999-9999', 'YeongGwang');
insert into customer values ('person5', 'a43244', 'South Korea', '010-1545-5674', 'Seoul');
insert into customer values ('person6', '23424', 'South Korea', '010-3245-8664', 'Seoul');
insert into customer values ('person7', '52352', 'South Korea', '010-1785-2342', 'Seoul');
insert into customer values ('person8', '523525', 'South Korea', '010-8245-5531', 'Seoul');
insert into customer values ('person9', 'a23423', 'South Korea', '010-4256-5324', 'Seoul');
insert into customer values ('person10','234123', 'South Korea', '010-3959-5654', 'Seoul');



insert into deliver values
('moon123','MokPo','010-5049-0724');

insert into ordering values
('wonjong', 'CheongGye', 1234, 10000, 1, 1000,'2018-12-16'),
('inchan', 'NamAk', 1235, 4500, 1, 7500,'2018-12-01');

insert into cart values
('lee111',1,'초코파이 기본',7500,3,22500),
('lee111',2,'초코파이 녹차맛',9500,1,9500);
